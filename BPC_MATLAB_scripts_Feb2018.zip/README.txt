Download everything by clicking 'Clone or Download' > 'Download ZIP'.

See file 'Introduction_README.pdf'.